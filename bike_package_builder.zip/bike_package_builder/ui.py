"""N-panel UI — compliance dashboard + segment card always visible;
everything else in collapsible dropdown sub-panels.
"""
import math
import bpy

from .core import bike_presets, rider_data, mm

_CATEGORY = "Bike-Pack"


# ── Helpers ──────────────────────────────────────────────────────────────────

def _bar(value, maxv, width=10):
    """Text fill-bar: '▓▓▓▓▓░░░░░' for value/maxv."""
    frac   = 0.0 if maxv <= 0 else max(0.0, min(1.0, value / maxv))
    filled = int(round(frac * width))
    return "▓" * filled + "░" * (width - filled)


def _kv(col, label, value, alert=False):
    """Compact key : value row."""
    row = col.row(align=True)
    if alert:
        row.alert = True
    s = row.split(factor=0.50)
    s.label(text=label)
    s.label(text=value)


# ── Main Panel ───────────────────────────────────────────────────────────────

class BPB_PT_main(bpy.types.Panel):
    bl_label       = "Bike Package"
    bl_space_type  = "VIEW_3D"
    bl_region_type = "UI"
    bl_category    = _CATEGORY

    def draw(self, context):
        layout = self.layout
        props  = context.scene.bpb_props

        # ── Generate ──
        row = layout.row()
        row.scale_y = 1.4
        row.operator("bpb.generate", text="Generate Package")

        # ════════════════════════════════════════════════════
        # COMPLIANCE DASHBOARD
        # ════════════════════════════════════════════════════
        max_l = props.segment_max_length
        max_w = props.segment_max_width
        max_h = props.segment_max_height
        over_l = props.overall_length >= max_l
        over_w = props.overall_width  >= max_w
        over_h = props.overall_height >= max_h

        dash = layout.box()
        seg_name = props.segment_enum or "—"
        dash.label(text=seg_name)

        bars = dash.column(align=True)
        bars.scale_y = 0.85
        self._bar_row(bars, "L", props.overall_length, max_l, over_l)
        self._bar_row(bars, "W", props.overall_width,  max_w, over_w)
        self._bar_row(bars, "H", props.overall_height, max_h, over_h)

        if over_l or over_w or over_h:
            r = dash.row()
            r.alert = True
            r.label(text="At segment limit")

        # Lean angle readout
        lean_row = dash.row()
        lean_row.label(text="Max Lean: %.1f°" % props.max_lean_angle)

        # ════════════════════════════════════════════════════
        # BIKE SEGMENT CARD
        # ════════════════════════════════════════════════════
        card = layout.box()
        card.label(text="Bike Segment")
        row = card.row(align=True)
        row.prop(props, "segment_enum", text="")
        row.operator("bpb.apply_segment_enum", text="Apply")

        data = bike_presets().get(props.segment_enum)
        if data:
            sub = card.row()
            sub.scale_y = 0.8
            sub.label(text=data.get("category", ""))

    @staticmethod
    def _bar_row(col, letter, value, maxv, at_limit):
        row = col.row(align=True)
        row.alert = at_limit
        s1 = row.split(factor=0.08)
        s1.label(text=letter)
        s2 = s1.split(factor=0.60)
        s2.label(text=_bar(value, maxv))
        s2.label(text="%.0f / %.0f" % (value, maxv))


# ── Sub-panel base ───────────────────────────────────────────────────────────

class _Sub(bpy.types.Panel):
    bl_space_type  = "VIEW_3D"
    bl_region_type = "UI"
    bl_category    = _CATEGORY
    bl_parent_id   = "BPB_PT_main"
    bl_options     = {"DEFAULT_CLOSED"}


# ── Posture Mode ─────────────────────────────────────────────────────────────

class BPB_PT_posture(_Sub):
    bl_label = "Riding Posture"

    def draw(self, context):
        props  = context.scene.bpb_props
        layout = self.layout
        row = layout.row(align=True)
        row.prop(props, "posture_enum", text="")
        row.operator("bpb.apply_posture_enum", text="Apply")
        sub = layout.row()
        sub.scale_y = 0.8
        lean_text = "Reclined" if props.forward_lean < 0 else "Lean"
        sub.label(text="%s %.0f°  Seat %.0f mm"
                  % (lean_text, abs(props.forward_lean), props.seat_height))


# ── Bike Size ────────────────────────────────────────────────────────────────

class BPB_PT_size(_Sub):
    bl_label = "Bike Size"

    def draw(self, context):
        props  = context.scene.bpb_props
        layout = self.layout
        col = layout.column(align=True)
        col.prop(props, "overall_length")
        col.prop(props, "overall_width")
        col.prop(props, "overall_height")
        col.prop(props, "ground_clearance")
        layout.separator(factor=0.3)
        layout.prop(props, "show_silhouette", toggle=True)

        # Derived readouts
        col2 = layout.column(align=True)
        col2.scale_y = 0.85
        _kv(col2, "Wheelbase", "%.0f mm" % props.wheelbase)


# ── Steering Geometry ────────────────────────────────────────────────────────

class BPB_PT_steering(_Sub):
    bl_label = "Steering Geometry"

    def draw(self, context):
        props  = context.scene.bpb_props
        layout = self.layout
        col = layout.column(align=True)
        col.prop(props, "rake_angle")
        col.prop(props, "trail")

        layout.separator(factor=0.3)
        col2 = layout.column(align=True)
        col2.prop(props, "wheelbase")
        col2.prop(props, "front_overhang")
        col2.prop(props, "rear_overhang")


# ── Rider ────────────────────────────────────────────────────────────────────

class BPB_PT_rider(_Sub):
    bl_label = "Rider"

    def draw(self, context):
        props  = context.scene.bpb_props
        layout = self.layout
        row = layout.row(align=True)
        row.prop(props, "percentile", text="")

        col = layout.column(align=True)
        col.prop(props, "seat_height")
        col.prop(props, "seat_fore_aft")
        col.prop(props, "forward_lean")


# ── Controls (Handlebar + Footpeg) ──────────────────────────────────────────

class BPB_PT_controls(_Sub):
    bl_label = "Handlebar & Footpeg"

    def draw(self, context):
        props  = context.scene.bpb_props
        layout = self.layout

        layout.label(text="Handlebar")
        col = layout.column(align=True)
        col.prop(props, "handlebar_height")
        col.prop(props, "handlebar_width")

        layout.separator(factor=0.3)
        layout.label(text="Footpeg")
        col2 = layout.column(align=True)
        col2.prop(props, "footpeg_height")
        col2.prop(props, "footpeg_fore_aft")


# ── Tires ────────────────────────────────────────────────────────────────────

class BPB_PT_tires(_Sub):
    bl_label = "Tires"

    def draw(self, context):
        props  = context.scene.bpb_props
        layout = self.layout

        layout.label(text="Tire Codes")
        col = layout.column(align=True)
        col.prop(props, "front_tire_code", text="Front")
        col.prop(props, "rear_tire_code", text="Rear")

        layout.separator(factor=0.3)
        col2 = layout.column(align=True)
        col2.scale_y = 0.85
        _kv(col2, "Front Ø", "%.0f mm" % props.front_tire_diameter)
        _kv(col2, "Rear Ø",  "%.0f mm" % props.rear_tire_diameter)
        _kv(col2, "Front W", "%.0f mm" % props.front_tire_width)
        _kv(col2, "Rear W",  "%.0f mm" % props.rear_tire_width)

        layout.separator(factor=0.3)
        layout.label(text="Tire Catalog")
        row = layout.row(align=True)
        row.prop(props, "tire_catalog_enum", text="")
        row.operator("bpb.apply_tire_enum", text="Apply")


# ── Lean Angle ───────────────────────────────────────────────────────────────

class BPB_PT_lean(_Sub):
    bl_label = "Lean Angle"

    def draw(self, context):
        props  = context.scene.bpb_props
        layout = self.layout
        layout.prop(props, "show_lean_angle", toggle=True)
        col = layout.column(align=True)
        col.scale_y = 0.85
        _kv(col, "Max Lean", "%.1f°" % props.max_lean_angle)
        _kv(col, "Peg Height", "%.0f mm" % props.footpeg_height)
        _kv(col, "Ground CL", "%.0f mm" % props.ground_clearance)


# ── Viewport-header quick-switch ─────────────────────────────────────────────

class BPB_PT_header_popover(bpy.types.Panel):
    bl_label       = "Bike Pack Quick Switch"
    bl_space_type  = "VIEW_3D"
    bl_region_type = "HEADER"

    def draw(self, context):
        props  = context.scene.bpb_props
        layout = self.layout
        layout.label(text="Segment")
        row = layout.row(align=True)
        row.prop(props, "segment_enum", text="")
        row.operator("bpb.apply_segment_enum", text="Apply")
        layout.separator()
        layout.label(text="Posture")
        row = layout.row(align=True)
        row.prop(props, "posture_enum", text="")
        row.operator("bpb.apply_posture_enum", text="Apply")
        layout.separator()
        layout.operator("bpb.generate", text="Generate")


def draw_header_quick_switch(self, context):
    if getattr(context.scene, "bpb_props", None) is None:
        return
    self.layout.popover(panel="BPB_PT_header_popover", text="Bike-Pack")


# ── Registration ─────────────────────────────────────────────────────────────

classes = (
    BPB_PT_main,
    BPB_PT_posture,
    BPB_PT_size,
    BPB_PT_steering,
    BPB_PT_rider,
    BPB_PT_controls,
    BPB_PT_tires,
    BPB_PT_lean,
    BPB_PT_header_popover,
)
