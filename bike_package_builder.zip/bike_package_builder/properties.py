"""Parametric properties for the Bike Package Builder. All lengths in millimetres.

Labels follow the pattern: Plain English Name so non-engineers can understand
the controls. Segment dimension enforcement mirrors the car builder pattern.
"""
import bpy
from bpy.props import (
    FloatProperty, IntProperty, BoolProperty, EnumProperty, FloatVectorProperty,
    StringProperty
)

from .core import update, tirecode, bike_presets, posture_modes, tire_catalog


# ── Segment enum items ────────────────────────────────────────────────────────

def _segment_items(self, context):
    """Dynamic EnumProperty items from bike_presets.json."""
    items = []
    presets = bike_presets()
    by_cat = {}
    for name, data in presets.items():
        by_cat.setdefault(data.get("category", "Other"), []).append(name)
    idx = 0
    for category in ("Street", "Performance", "Off-Road & Adventure",
                      "Cruiser & Touring", "Electric"):
        names = by_cat.get(category)
        if not names:
            continue
        for name in names:
            idx += 1
            cat_tag = "  [%s]" % category[:3].upper()
            items.append((name, name + cat_tag,
                          "Load %s preset (%s)" % (name, category),
                          "NONE", idx))
    return items if items else [("NONE", "No Presets", "", "NONE", 0)]


def _posture_items(self, context):
    """Dynamic EnumProperty items from posture_modes.json."""
    items = []
    modes = posture_modes()
    by_cat = {}
    for name, data in modes.items():
        by_cat.setdefault(data.get("category", "Other"), []).append(name)
    idx = 0
    for category in ("Comfort", "Performance", "Cruiser", "Off-Road"):
        names = by_cat.get(category)
        if not names:
            continue
        for name in names:
            idx += 1
            items.append((name, name,
                          "%s posture (%s)" % (name, category),
                          "NONE", idx))
    return items if items else [("NONE", "No Modes", "", "NONE", 0)]


def _tire_catalog_items(self, context):
    """Dynamic EnumProperty items from tire_catalog.json."""
    items = []
    catalog = tire_catalog()
    idx = 0
    for name, data in catalog.items():
        idx += 1
        code = data.get("front_code", "")
        label = "%s  (%s)" % (name, code) if code else name
        items.append((name, label, "Apply %s tire" % name, "NONE", idx))
    return items if items else [("NONE", "No Tires", "", "NONE", 0)]


# ── Callbacks ────────────────────────────────────────────────────────────────

def _refresh(self, context):
    _enforce_segment_limits(self)
    update.refresh(context)


def _enforce_segment_limits(props):
    """Hard-clamp overall_length, overall_width, overall_height to segment maximums."""
    if props.overall_length > props.segment_max_length:
        props["overall_length"] = props.segment_max_length
    if props.overall_width > props.segment_max_width:
        props["overall_width"] = props.segment_max_width
    if props.overall_height > props.segment_max_height:
        props["overall_height"] = props.segment_max_height


def _apply_front_tire_code(self, context):
    parsed = tirecode.parse(self.front_tire_code)
    if parsed:
        self.front_tire_width = parsed["width"]
        self.front_tire_diameter = parsed["diameter"]
    update.refresh(context)


def _apply_rear_tire_code(self, context):
    parsed = tirecode.parse(self.rear_tire_code)
    if parsed:
        self.rear_tire_width = parsed["width"]
        self.rear_tire_diameter = parsed["diameter"]
    update.refresh(context)


class BikePackageProperties(bpy.types.PropertyGroup):

    # ── Segment Selection ────────────────────────────────────────────────────
    segment_enum: EnumProperty(
        name="Bike Segment",
        description="Choose a motorcycle segment preset",
        items=_segment_items)

    posture_enum: EnumProperty(
        name="Riding Posture",
        description="Choose a riding posture mode",
        items=_posture_items)

    tire_catalog_enum: EnumProperty(
        name="Tire Preset",
        description="Choose a tire catalog preset",
        items=_tire_catalog_items)

    # ── Bike Size ────────────────────────────────────────────────────────────
    overall_length: FloatProperty(
        name="Overall Length",
        description="Total length from front to rear tip",
        default=2055.0, min=1500.0, max=2800.0, update=_refresh)
    overall_width: FloatProperty(
        name="Overall Width",
        description="Maximum body width (excluding mirrors)",
        default=765.0, min=500.0, max=1100.0, update=_refresh)
    overall_height: FloatProperty(
        name="Overall Height",
        description="Total height from ground to highest point",
        default=1060.0, min=800.0, max=1600.0, update=_refresh)
    ground_clearance: FloatProperty(
        name="Ground Clearance",
        description="Minimum gap between underbody and ground",
        default=160.0, min=80.0, max=300.0, update=_refresh)
    show_silhouette: BoolProperty(
        name="Show Silhouette",
        description="Toggle the wireframe body envelope on/off",
        default=True, update=_refresh)

    # ── Wheelbase & Axles ────────────────────────────────────────────────────
    wheelbase: FloatProperty(
        name="Wheelbase",
        description="Distance between front and rear axle centres",
        default=1320.0, min=900.0, max=1800.0, update=_refresh)
    front_overhang: FloatProperty(
        name="Front Overhang",
        description="Distance from front tip to front axle centre",
        default=367.0, min=100.0, max=600.0, update=_refresh)
    rear_overhang: FloatProperty(
        name="Rear Overhang",
        description="Distance from rear axle centre to rear tip",
        default=368.0, min=100.0, max=600.0, update=_refresh)

    # ── Steering Geometry ────────────────────────────────────────────────────
    rake_angle: FloatProperty(
        name="Rake Angle",
        description="Steering head angle from vertical (degrees)",
        default=26.0, min=18.0, max=45.0, update=_refresh)
    trail: FloatProperty(
        name="Trail",
        description="Ground distance between steering axis and tyre contact",
        default=100.0, min=50.0, max=200.0, update=_refresh)

    # ── Seat ─────────────────────────────────────────────────────────────────
    seat_height: FloatProperty(
        name="Seat Height",
        description="Vertical distance from ground to seat surface",
        default=785.0, min=600.0, max=950.0, update=_refresh)
    seat_fore_aft: FloatProperty(
        name="Seat Position",
        description="Fore-aft distance from front axle to seat point",
        default=650.0, min=300.0, max=1200.0, update=_refresh)

    # ── Rider ────────────────────────────────────────────────────────────────
    percentile: EnumProperty(
        name="Body Size",
        description="Rider body size percentile",
        items=[('5',  "Small (5th %ile)",  "Small body proportions"),
               ('50', "Medium (50th %ile)", "Average body proportions"),
               ('95', "Large (95th %ile)",  "Large body proportions")],
        default='50', update=_refresh)
    forward_lean: FloatProperty(
        name="Forward Lean",
        description="Torso tilt angle forward from vertical (negative = reclined)",
        default=12.0, min=-15.0, max=55.0, update=_refresh)

    # ── Handlebar ────────────────────────────────────────────────────────────
    handlebar_height: FloatProperty(
        name="Handlebar Height",
        description="Height of handlebar grips from ground",
        default=1010.0, min=700.0, max=1200.0, update=_refresh)
    handlebar_width: FloatProperty(
        name="Handlebar Width",
        description="Distance between left and right grip tips",
        default=720.0, min=500.0, max=1000.0, update=_refresh)

    # ── Footpeg ──────────────────────────────────────────────────────────────
    footpeg_height: FloatProperty(
        name="Footpeg Height",
        description="Height of footpeg centres from ground",
        default=300.0, min=150.0, max=500.0, update=_refresh)
    footpeg_fore_aft: FloatProperty(
        name="Footpeg Position",
        description="Distance behind front axle to footpeg centre",
        default=580.0, min=300.0, max=900.0, update=_refresh)

    # ── Tires ────────────────────────────────────────────────────────────────
    front_tire_code: StringProperty(
        name="Front Tire Code",
        description="Front tire size (e.g. 80/100-17 or 120/70ZR17)",
        default="80/100-17", update=_apply_front_tire_code)
    rear_tire_code: StringProperty(
        name="Rear Tire Code",
        description="Rear tire size (e.g. 130/70-17 or 180/55ZR17)",
        default="130/70-17", update=_apply_rear_tire_code)
    front_tire_diameter: FloatProperty(
        name="Front Tire Diameter",
        description="Computed front tire outer diameter",
        default=592.0, min=300.0, max=800.0, update=_refresh)
    front_tire_width: FloatProperty(
        name="Front Tire Width",
        description="Front tire section width",
        default=80.0, min=50.0, max=200.0, update=_refresh)
    rear_tire_diameter: FloatProperty(
        name="Rear Tire Diameter",
        description="Computed rear tire outer diameter",
        default=614.0, min=300.0, max=800.0, update=_refresh)
    rear_tire_width: FloatProperty(
        name="Rear Tire Width",
        description="Rear tire section width",
        default=130.0, min=50.0, max=250.0, update=_refresh)

    # ── Lean Angle ───────────────────────────────────────────────────────────
    show_lean_angle: BoolProperty(
        name="Show Lean Angle",
        description="Toggle lean angle clearance visualization",
        default=True, update=_refresh)
    max_lean_angle: FloatProperty(
        name="Max Lean Angle",
        description="Computed maximum lean angle before peg scrape (read-only)",
        default=45.0, min=0.0, max=90.0)

    # ── Segment Limits ───────────────────────────────────────────────────────
    segment_max_length: FloatProperty(
        name="Segment Max Length",
        description="Hard upper length bound for the loaded segment",
        default=2800.0, min=1500.0, max=3500.0)
    segment_max_width: FloatProperty(
        name="Segment Max Width",
        description="Hard upper width bound for the loaded segment",
        default=1100.0, min=500.0, max=1500.0)
    segment_max_height: FloatProperty(
        name="Segment Max Height",
        description="Hard upper height bound for the loaded segment",
        default=1600.0, min=800.0, max=2000.0)

    # ── Appearance ───────────────────────────────────────────────────────────
    color_rider: FloatVectorProperty(
        name="Rider Color", subtype='COLOR', size=4,
        default=(0.90, 0.55, 0.15, 1.0), min=0.0, max=1.0)
    color_tires: FloatVectorProperty(
        name="Tire Color", subtype='COLOR', size=4,
        default=(0.05, 0.05, 0.05, 1.0), min=0.0, max=1.0)
    color_chassis: FloatVectorProperty(
        name="Chassis Color", subtype='COLOR', size=4,
        default=(0.7, 0.85, 1.0, 1.0), min=0.0, max=1.0)
    limb_thickness: FloatProperty(
        name="Limb Thickness",
        description="Visual thickness of the rider limbs",
        default=1.0, min=0.3, max=3.0)
