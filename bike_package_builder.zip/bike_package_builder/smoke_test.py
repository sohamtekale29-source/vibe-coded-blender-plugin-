"""Smoke test for the Bike Package Builder add-on.

Run inside Blender's scripting workspace:
  1. Open this file in Blender's Text Editor
  2. Press Run Script (Alt+P)

Or from command line:
  blender --background --python bike_package_builder/smoke_test.py

Tests:
  - Add-on registration
  - Package generation (all objects created)
  - Preset loading (all 8 segments)
  - Posture mode application (all 7 modes)
  - Tire code parsing
  - Property update (slider changes trigger refresh)
  - Cleanup
"""
import sys
import os

# Ensure the add-on parent directory is on sys.path
_this = os.path.dirname(os.path.abspath(__file__))
_parent = os.path.dirname(_this)
if _parent not in sys.path:
    sys.path.insert(0, _parent)

import bpy

PASS = 0
FAIL = 0


def _test(name, condition):
    global PASS, FAIL
    if condition:
        PASS += 1
        print("  ✓ %s" % name)
    else:
        FAIL += 1
        print("  ✗ FAIL: %s" % name)


def run():
    global PASS, FAIL
    PASS, FAIL = 0, 0

    print("\n" + "=" * 60)
    print("  Bike Package Builder — Smoke Test")
    print("=" * 60)

    # ── 1. Registration ──────────────────────────────────────────────────
    print("\n── Registration ──")
    from bike_package_builder import register, unregister
    try:
        register()
        reg_ok = True
    except Exception as e:
        reg_ok = False
        print("    Registration error: %s" % e)
    _test("Add-on registers without error", reg_ok)
    _test("bpb_props exists on Scene", hasattr(bpy.types.Scene, "bpb_props"))

    props = bpy.context.scene.bpb_props

    # ── 2. Tire code parsing ─────────────────────────────────────────────
    print("\n── Tire Code Parsing ──")
    from bike_package_builder.core import tirecode
    r1 = tirecode.parse("120/70ZR17")
    _test("Parse 120/70ZR17 → width=120", r1 and r1["width"] == 120)
    _test("Parse 120/70ZR17 → aspect=70", r1 and r1["aspect"] == 70)
    _test("Parse 120/70ZR17 → rim=17", r1 and r1["rim_in"] == 17)
    _test("Parse 120/70ZR17 → diameter ~600mm", r1 and 590 < r1["diameter"] < 610)

    r2 = tirecode.parse("80/100-17")
    _test("Parse 80/100-17 (commuter)", r2 is not None)
    _test("Parse 80/100-17 → width=80", r2 and r2["width"] == 80)

    r3 = tirecode.parse("90/90-12")
    _test("Parse 90/90-12 (scooter)", r3 is not None)

    r4 = tirecode.parse("not a tire code")
    _test("Reject invalid code → None", r4 is None)

    # ── 3. Data loading ──────────────────────────────────────────────────
    print("\n── Data Loading ──")
    from bike_package_builder.core import rider_data, bike_presets, posture_modes, tire_catalog
    rd = rider_data()
    _test("rider_data has 3 percentiles", len(rd) == 3)
    _test("50th has upper_leg", "upper_leg" in rd.get("50", {}))

    bp = bike_presets()
    _test("bike_presets has 8 segments", len(bp) == 8)
    _test("Commuter preset exists", "Commuter" in bp)

    pm = posture_modes()
    _test("posture_modes has 7 modes", len(pm) == 7)

    tc = tire_catalog()
    _test("tire_catalog has entries", len(tc) >= 5)

    # ── 4. Generate package ──────────────────────────────────────────────
    print("\n── Generate Package ──")
    bpy.ops.bpb.generate()
    coll = bpy.data.collections.get("Bike Package")
    _test("Collection 'Bike Package' exists", coll is not None)

    if coll:
        obj_names = [o.name for o in coll.objects]
        _test("Front tire exists", "BPB_Tire_Front" in obj_names)
        _test("Rear tire exists", "BPB_Tire_Rear" in obj_names)
        _test("Front axle exists", "BPB_Axle_Front" in obj_names)
        _test("Rear axle exists", "BPB_Axle_Rear" in obj_names)
        _test("Seat point exists", "BPB_Seat_Point" in obj_names)
        _test("Silhouette exists", "BPB_Silhouette" in obj_names)
        _test("Rider hip exists", "BPB_RIDER_Hip" in obj_names)
        _test("Rider head exists", "BPB_RIDER_Head" in obj_names)
        _test("Left handlebar exists", "BPB_Handlebar_L" in obj_names)
        _test("Right footpeg exists", "BPB_Footpeg_R" in obj_names)
        _test("Lean angle L exists", "BPB_Lean_L" in obj_names)
        _test("Fork line exists", "BPB_Fork_Line" in obj_names)

        # Check rider arm/leg joints
        _test("Rider L shoulder exists", "BPB_RIDER_L_Shoulder" in obj_names)
        _test("Rider R knee exists", "BPB_RIDER_R_Knee" in obj_names)
        _test("Rider L ankle exists", "BPB_RIDER_L_Ankle" in obj_names)

        total_objs = len(obj_names)
        _test("Total objects >= 30", total_objs >= 30)
        print("    (Total objects in collection: %d)" % total_objs)

    # ── 5. Preset loading ────────────────────────────────────────────────
    print("\n── Preset Loading ──")
    for seg_name in bp.keys():
        props.segment_enum = seg_name
        bpy.ops.bpb.apply_segment_enum()
        _test("Load preset: %s" % seg_name,
              abs(props.overall_length - bp[seg_name]["overall_length"]) < 1.0)

    # ── 6. Posture modes ─────────────────────────────────────────────────
    print("\n── Posture Modes ──")
    for mode_name, mode_data in pm.items():
        props.posture_enum = mode_name
        bpy.ops.bpb.apply_posture_enum()
        expected_lean = mode_data.get("forward_lean", props.forward_lean)
        _test("Posture %s → lean=%.0f" % (mode_name, expected_lean),
              abs(props.forward_lean - expected_lean) < 0.1)

    # ── 7. Property updates ──────────────────────────────────────────────
    print("\n── Property Updates ──")
    props.seat_height = 850.0
    _test("Seat height update accepted", abs(props.seat_height - 850.0) < 0.1)
    props.forward_lean = 30.0
    _test("Forward lean update accepted", abs(props.forward_lean - 30.0) < 0.1)
    props.rake_angle = 28.0
    _test("Rake angle update accepted", abs(props.rake_angle - 28.0) < 0.1)

    # ── 8. Cleanup ───────────────────────────────────────────────────────
    print("\n── Cleanup ──")
    try:
        unregister()
        unreg_ok = True
    except Exception as e:
        unreg_ok = False
        print("    Unregister error: %s" % e)
    _test("Add-on unregisters without error", unreg_ok)
    _test("bpb_props removed", not hasattr(bpy.types.Scene, "bpb_props"))

    # ── Summary ──────────────────────────────────────────────────────────
    print("\n" + "=" * 60)
    total = PASS + FAIL
    print("  Results: %d / %d passed" % (PASS, total))
    if FAIL:
        print("  ⚠ %d FAILED" % FAIL)
    else:
        print("  ✓ All tests passed!")
    print("=" * 60 + "\n")


if __name__ == "__main__":
    run()
