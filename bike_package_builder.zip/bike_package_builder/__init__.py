"""Bike Package Builder -- a parametric motorcycle packaging rig for Blender.

Inspired by the rider triangle methodology (ISO 6725/6726) and Cycle-Ergo
ergonomics. MVP: parametric rider manikin, motorcycle skeleton (wheelbase/
seat height/handlebar/footpeg/rake/trail), tires, lean angle clearance,
and an N-panel UI with segment presets.
"""
bl_info = {
    "name": "Bike Package Builder",
    "author": "Soham Tekale",
    "version": (0, 1, 0),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar (N) > Bike-Pack",
    "description": "Parametric motorcycle package layout with rider triangle ergonomics",
    "category": "Add Mesh",
}

import bpy
from bpy.props import PointerProperty

from . import properties, ops, ui

_classes = (properties.BikePackageProperties, *ops.classes, *ui.classes)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.bpb_props = PointerProperty(type=properties.BikePackageProperties)
    try:
        bpy.types.VIEW3D_HT_header.append(ui.draw_header_quick_switch)
    except Exception:
        pass


def unregister():
    try:
        bpy.types.VIEW3D_HT_header.remove(ui.draw_header_quick_switch)
    except Exception:
        pass
    del bpy.types.Scene.bpb_props
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
