"""Operators: generate/rebuild the package, load presets/catalogs, apply postures."""
import bpy
from bpy.props import StringProperty

from .core import builder, update, bike_presets, tire_catalog, posture_modes
from .core import tirecode
from .properties import _enforce_segment_limits


def _apply_attrs(props, data, skip=()):
    """setattr every key in data that matches a real property, casting type.

    segment_max_* keys are applied FIRST so dimension setters can clamp correctly.
    """
    items = sorted(data.items(),
                   key=lambda kv: 0 if kv[0].startswith("segment_max") else 1)
    for key, value in items:
        if key in skip or not hasattr(props, key):
            continue
        try:
            setattr(props, key, float(value))
        except TypeError:
            try:
                setattr(props, key, int(value))
            except TypeError:
                setattr(props, key, str(value))


class BPB_OT_generate(bpy.types.Operator):
    bl_idname = "bpb.generate"
    bl_label = "Generate / Rebuild Package"
    bl_description = "Create (or recreate) the Bike Package rig from the current settings"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        builder.build(context)
        self.report({"INFO"}, "Bike package generated")
        return {"FINISHED"}


class BPB_OT_load_preset(bpy.types.Operator):
    bl_idname = "bpb.load_preset"
    bl_label = "Load Preset"
    bl_description = "Apply a bike-segment preset to the current settings"
    bl_options = {"REGISTER", "UNDO"}

    preset: StringProperty(name="Preset", default="Commuter")

    def execute(self, context):
        data = bike_presets().get(self.preset)
        if data is None:
            self.report({"ERROR"}, "Unknown preset: %s" % self.preset)
            return {"CANCELLED"}
        props = context.scene.bpb_props
        _apply_attrs(props, data, skip=("category",))
        # Derive wheelbase and overhangs from overall_length
        wb = data.get("wheelbase", 1320)
        ol = data.get("overall_length", 2055)
        fo = data.get("front_overhang", (ol - wb) * 0.5)
        ro = ol - wb - fo
        props.wheelbase = wb
        props.front_overhang = fo
        props.rear_overhang = ro
        # Derive seat fore-aft from wheelbase
        props.seat_fore_aft = fo + wb * 0.45  # Seat roughly at 45% of wheelbase
        _enforce_segment_limits(props)
        update.refresh(context)
        self.report({"INFO"}, "Loaded preset: %s" % self.preset)
        return {"FINISHED"}


class BPB_OT_apply_tire_catalog(bpy.types.Operator):
    bl_idname = "bpb.apply_tire_catalog"
    bl_label = "Apply Tire Catalog Entry"
    bl_description = "Set front/rear tire codes from a catalog entry"
    bl_options = {"REGISTER", "UNDO"}

    entry: StringProperty(name="Catalog Entry", default="Commuter")

    def execute(self, context):
        data = tire_catalog().get(self.entry)
        if data is None:
            self.report({"ERROR"}, "Unknown tire catalog entry: %s" % self.entry)
            return {"CANCELLED"}
        props = context.scene.bpb_props
        front_code = data.get("front_code", "")
        rear_code = data.get("rear_code", "")
        if front_code:
            props.front_tire_code = front_code
        if rear_code:
            props.rear_tire_code = rear_code
        update.refresh(context)
        self.report({"INFO"}, "Applied tire catalog entry: %s" % self.entry)
        return {"FINISHED"}


class BPB_OT_apply_posture(bpy.types.Operator):
    bl_idname = "bpb.apply_posture"
    bl_label = "Apply Posture Mode"
    bl_description = "Apply a named riding posture mode into the current settings"
    bl_options = {"REGISTER", "UNDO"}

    mode: StringProperty(name="Posture Mode", default="Upright")

    def execute(self, context):
        data = posture_modes().get(self.mode)
        if data is None:
            self.report({"ERROR"}, "Unknown posture mode: %s" % self.mode)
            return {"CANCELLED"}
        props = context.scene.bpb_props
        _apply_attrs(props, data, skip=("category",))
        _enforce_segment_limits(props)
        update.refresh(context)
        self.report({"INFO"}, "Applied posture mode: %s" % self.mode)
        return {"FINISHED"}


# ── Enum-driven operators ────────────────────────────────────────────────────

class BPB_OT_apply_segment_enum(bpy.types.Operator):
    bl_idname = "bpb.apply_segment_enum"
    bl_label = "Apply Selected Segment"
    bl_description = "Apply the segment chosen in the dropdown"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props = context.scene.bpb_props
        preset_name = props.segment_enum
        if not preset_name:
            self.report({"WARNING"}, "No segment selected")
            return {"CANCELLED"}
        data = bike_presets().get(preset_name)
        if data is None:
            self.report({"ERROR"}, "Unknown preset: %s" % preset_name)
            return {"CANCELLED"}
        _apply_attrs(props, data, skip=("category",))
        # Derive wheelbase/overhangs
        wb = data.get("wheelbase", 1320)
        ol = data.get("overall_length", 2055)
        fo = data.get("front_overhang", (ol - wb) * 0.5)
        ro = ol - wb - fo
        props.wheelbase = wb
        props.front_overhang = fo
        props.rear_overhang = ro
        props.seat_fore_aft = fo + wb * 0.45
        _enforce_segment_limits(props)
        update.refresh(context)
        self.report({"INFO"}, "Applied segment: %s" % preset_name)
        return {"FINISHED"}


class BPB_OT_apply_posture_enum(bpy.types.Operator):
    bl_idname = "bpb.apply_posture_enum"
    bl_label = "Apply Selected Posture"
    bl_description = "Apply the posture mode chosen in the dropdown"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props = context.scene.bpb_props
        mode_name = props.posture_enum
        if not mode_name:
            self.report({"WARNING"}, "No posture selected")
            return {"CANCELLED"}
        data = posture_modes().get(mode_name)
        if data is None:
            self.report({"ERROR"}, "Unknown posture: %s" % mode_name)
            return {"CANCELLED"}
        _apply_attrs(props, data, skip=("category",))
        _enforce_segment_limits(props)
        update.refresh(context)
        self.report({"INFO"}, "Applied posture: %s" % mode_name)
        return {"FINISHED"}


class BPB_OT_apply_tire_enum(bpy.types.Operator):
    bl_idname = "bpb.apply_tire_enum"
    bl_label = "Apply Selected Tire"
    bl_description = "Apply the tire preset chosen in the dropdown"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props = context.scene.bpb_props
        entry_name = props.tire_catalog_enum
        if not entry_name:
            self.report({"WARNING"}, "No tire preset selected")
            return {"CANCELLED"}
        data = tire_catalog().get(entry_name)
        if data is None:
            self.report({"ERROR"}, "Unknown tire entry: %s" % entry_name)
            return {"CANCELLED"}
        front_code = data.get("front_code", "")
        rear_code = data.get("rear_code", "")
        if front_code:
            props.front_tire_code = front_code
        if rear_code:
            props.rear_tire_code = rear_code
        update.refresh(context)
        self.report({"INFO"}, "Applied tire preset: %s" % entry_name)
        return {"FINISHED"}


classes = (
    BPB_OT_generate,
    BPB_OT_load_preset,
    BPB_OT_apply_tire_catalog,
    BPB_OT_apply_posture,
    BPB_OT_apply_segment_enum,
    BPB_OT_apply_posture_enum,
    BPB_OT_apply_tire_enum,
)
