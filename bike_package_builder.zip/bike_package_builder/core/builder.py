"""One-shot package builder: clears old rig and recreates everything from scratch."""
import bpy
from . import meshutil, rider, chassis, tires, lean, update


def build(context):
    meshutil.clear(context)
    coll = bpy.data.collections.new(meshutil.COLLECTION)
    context.scene.collection.children.link(coll)

    tires.build(coll)
    chassis.build(coll)
    lean.build(coll)
    rider.build_all(coll, context.scene.bpb_props)

    update.refresh(context)
    return coll
