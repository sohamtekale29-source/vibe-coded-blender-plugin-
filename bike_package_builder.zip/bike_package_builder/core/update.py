"""Update engine: reposition all existing BPB_ objects from current props.

Called by property update callbacks (live slider changes) and at end of build.
"""
from . import meshutil, rider, chassis, tires, lean, appearance

_building = False


def refresh(context):
    global _building
    if _building:
        return
    coll = meshutil.get_collection()
    if coll is None:
        return

    props = context.scene.bpb_props

    # Detect rider-count change (Phase 3: pillion). Rebuild if expected rider is absent.
    expected = [p for p, *_ in rider.rider_layout(props)]
    missing  = [p for p in expected
                if coll.objects.get("BPB_%s_Hip" % p) is None]
    if missing:
        _building = True
        try:
            from . import builder
            builder.build(context)
        finally:
            _building = False
        return

    tires.position(coll, props)
    chassis.position(coll, props)
    lean.position(coll, props)
    rider.position_all(coll, props)
    appearance.apply_colors(coll, props)
