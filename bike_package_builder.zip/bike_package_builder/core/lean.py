"""Lean angle clearance visualization — bike-specific feature.

Shows the maximum lean angle before the footpeg contacts the ground.
Visualized as a pair of angled lines from the ground contact patch
to the footpeg position, representing the lean limit on each side.

max_lean = arctan(peg_height / peg_lateral_distance)
"""
import math
import bpy
import bmesh
from . import meshutil

LEAN_LEFT  = "BPB_Lean_L"
LEAN_RIGHT = "BPB_Lean_R"
LEAN_ARC   = "BPB_Lean_Arc"


def build(coll):
    """Create lean angle visualization objects."""
    # Left and right lean limit lines
    for name in (LEAN_LEFT, LEAN_RIGHT):
        bm = bmesh.new()
        v0 = bm.verts.new((0.0, 0.0, 0.0))
        v1 = bm.verts.new((0.0, 0.0, 1.0))
        bm.edges.new((v0, v1))
        me = bpy.data.meshes.new(name)
        bm.to_mesh(me)
        bm.free()
        obj = meshutil.add_mesh_obj(coll, name, me)
        obj.display_type = 'WIRE'
        obj.color = (1.0, 0.3, 0.1, 0.8)


def position(coll, props):
    """Update lean angle lines from current properties."""
    from . import mm

    fp_z = mm(props.footpeg_height)
    fp_lateral = mm(150)  # Footpeg lateral offset from centreline

    # Max lean angle = arctan(peg_height / peg_lateral_distance)
    if fp_lateral > 0.001:
        max_lean_rad = math.atan2(fp_z, fp_lateral)
    else:
        max_lean_rad = math.radians(45.0)

    max_lean_deg = math.degrees(max_lean_rad)

    # Store computed value for UI readout
    try:
        props["max_lean_angle"] = max_lean_deg
    except Exception:
        pass

    # Position lean lines at the footpeg fore-aft position
    front_y = mm(props.front_overhang)
    fp_y = front_y + mm(props.footpeg_fore_aft)

    # Line length = hypotenuse from ground to peg
    line_len = math.sqrt(fp_z * fp_z + fp_lateral * fp_lateral)

    show = props.show_lean_angle

    # Left lean
    ll = meshutil.obj(coll, LEAN_LEFT)
    if ll:
        ll.location       = (0.0, fp_y, 0.0)
        ll.scale          = (1.0, 1.0, max(0.01, line_len))
        ll.rotation_euler = (0.0, max_lean_rad, 0.0)
        ll.hide_viewport  = not show
        ll.hide_render    = not show

    # Right lean (mirrored)
    lr = meshutil.obj(coll, LEAN_RIGHT)
    if lr:
        lr.location       = (0.0, fp_y, 0.0)
        lr.scale          = (1.0, 1.0, max(0.01, line_len))
        lr.rotation_euler = (0.0, -max_lean_rad, 0.0)
        lr.hide_viewport  = not show
        lr.hide_render    = not show
