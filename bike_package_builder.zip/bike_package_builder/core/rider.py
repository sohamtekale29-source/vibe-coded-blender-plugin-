"""Parametric motorcycle rider manikin — astride posture kinematic chain.

Coordinate convention (bike runs along Blender Y / green axis):
  Y=0  = front wheel contact patch   Y increases toward rear
  X    = lateral (X>0 = left side of bike)
  Z=0  = ground contact plane
  Rider faces toward -Y (front). Torso leans forward (toward -Y).
  Legs splay laterally; feet rest on footpegs at known positions.

Unlike the car manikin:
  - Rider sits ON TOP (no roof/wall containment)
  - Arms reach forward-down to handlebars (full arm chain)
  - Legs are astride — upper legs angle outward, lower legs drop to pegs
  - Forward lean replaces back-recline angle
"""
import math
from . import meshutil


# Rendered head sphere radius.
_HEAD_R = 0.08


def n(prefix, suffix):
    """Canonical BPB object name: BPB_{prefix}_{suffix}"""
    return "BPB_%s_%s" % (prefix, suffix)


def rider_layout(props):
    """Return list of (prefix, seat_y, seat_x) per rider.

    RIDER = primary rider; PILLION = rear passenger (Phase 3).
    seat_y = fore-aft from front-wheel contact; seat_x = lateral offset (0 for bikes).
    """
    from . import mm
    seat_y = mm(props.seat_fore_aft)
    seats = [("RIDER", seat_y, 0.0)]
    # Pillion support reserved for Phase 3
    return seats


# ── Kinematic chain ──────────────────────────────────────────────────────────

def _compute_chain(seat_y, seat_x, props):
    """Compute all joint world positions for one rider.

    Returns a dict of (X=lateral, Y=fore_aft, Z=vertical) tuples.
    """
    from . import rider_data, mm

    data       = rider_data()[props.percentile]
    upper_leg  = mm(data["upper_leg"])
    lower_leg  = mm(data["lower_leg"])
    torso_len  = mm(data["torso"])
    upper_arm  = mm(data["upper_arm"])
    forearm    = mm(data["forearm"])
    neck_len   = mm(data["neck_head"])
    eye_fwd    = mm(data["eye_forward"])
    eye_up     = mm(data["eye_up"])
    hip_w      = mm(data["hip_breadth"]) * 0.5
    shoulder_w = mm(data["shoulder_width"]) * 0.5

    seat_z    = mm(props.seat_height)
    lean      = math.radians(props.forward_lean)  # positive = forward

    # Handlebar grip targets (world coordinates)
    hb_z = mm(props.handlebar_height)
    hb_half_w = mm(props.handlebar_width) * 0.5
    # Handlebars are positioned relative to the front axle
    front_axle_y = mm(props.front_overhang)
    hb_y = front_axle_y  # Approximately at front axle fore-aft position

    # Footpeg targets (world coordinates)
    fp_z = mm(props.footpeg_height)
    fp_y = front_axle_y + mm(props.footpeg_fore_aft)
    fp_half_w = mm(150)  # Footpeg lateral offset ~150mm from centreline

    # ── P-Point / Hip (seat contact) ──
    hip = (seat_x, seat_y, seat_z)

    # ── Spine chain (leans forward toward -Y) ──
    shoulder_z = seat_z + math.cos(lean) * torso_len
    shoulder_y = seat_y - math.sin(lean) * torso_len
    shoulder_c = (seat_x, shoulder_y, shoulder_z)

    head_z = shoulder_z + math.cos(lean) * neck_len
    head_y = shoulder_y - math.sin(lean) * neck_len
    head_pt = (seat_x, head_y, head_z)

    eye_pt = (seat_x, head_y - eye_fwd, head_z - eye_up)

    # ── Arms (shoulder → elbow → wrist, targeting handlebar grips) ──
    # Compute for left and right arms separately.
    # Each arm targets its handlebar grip point. We use a simple 2-bone IK
    # approximation: compute the elbow position that places the wrist at the grip.
    arms = {}
    for side, sign in (("L", +1), ("R", -1)):
        shoulder_pos = (seat_x + sign * shoulder_w, shoulder_y, shoulder_z)
        grip = (seat_x + sign * hb_half_w, hb_y, hb_z)

        # Vector from shoulder to grip
        dx = grip[0] - shoulder_pos[0]
        dy = grip[1] - shoulder_pos[1]
        dz = grip[2] - shoulder_pos[2]
        dist = math.sqrt(dx*dx + dy*dy + dz*dz)

        total_arm = upper_arm + forearm
        if dist >= total_arm:
            # Arm fully extended — place elbow at midpoint
            t = upper_arm / total_arm
            elbow = (shoulder_pos[0] + dx * t,
                     shoulder_pos[1] + dy * t,
                     shoulder_pos[2] + dz * t)
            wrist = grip
        elif dist < 0.01:
            # Degenerate — shoulder on top of grip
            elbow = (shoulder_pos[0], shoulder_pos[1], shoulder_pos[2] - upper_arm)
            wrist = grip
        else:
            # Triangle law for elbow: use upper_arm / forearm as the two sides
            # Place elbow below the shoulder-grip line
            cos_a = (upper_arm*upper_arm + dist*dist - forearm*forearm) / (2.0*upper_arm*dist)
            cos_a = max(-1.0, min(1.0, cos_a))
            angle_a = math.acos(cos_a)

            # Direction from shoulder to grip (unit)
            ux, uy, uz = dx/dist, dy/dist, dz/dist
            # Perpendicular direction (downward bias)
            # Use cross product with world-up, then cross again for down-ish direction
            cross_x = uy * 0.0 - uz * 0.0  # ~0 if grip is roughly in front
            cross_y = uz * 1.0 - ux * 0.0
            cross_z = ux * 0.0 - uy * 1.0
            # Fallback: use a downward bias
            perp_x = -uz * uy
            perp_y = 0
            perp_z = -(1.0 - uz*uz)
            perp_len = math.sqrt(perp_x*perp_x + perp_z*perp_z)
            if perp_len < 0.001:
                perp_x, perp_y, perp_z = 0.0, 0.0, -1.0
                perp_len = 1.0
            perp_x /= perp_len
            perp_z /= perp_len

            elbow = (
                shoulder_pos[0] + ux * math.cos(angle_a) * upper_arm + perp_x * math.sin(angle_a) * upper_arm,
                shoulder_pos[1] + uy * math.cos(angle_a) * upper_arm + perp_y * math.sin(angle_a) * upper_arm,
                shoulder_pos[2] + uz * math.cos(angle_a) * upper_arm + perp_z * math.sin(angle_a) * upper_arm,
            )
            wrist = grip

        arms[side] = {
            "shoulder": shoulder_pos,
            "elbow": elbow,
            "wrist": wrist,
        }

    # ── Legs (hip → knee → ankle, targeting footpegs) ──
    # Legs splay outward from the hip. Upper leg angles outward and downward;
    # lower leg drops to the footpeg.
    legs = {}
    for side, sign in (("L", +1), ("R", -1)):
        hip_pos = (seat_x + sign * hip_w, seat_y, seat_z)
        peg = (seat_x + sign * fp_half_w, fp_y, fp_z)

        dx = peg[0] - hip_pos[0]
        dy = peg[1] - hip_pos[1]
        dz = peg[2] - hip_pos[2]
        dist = math.sqrt(dx*dx + dy*dy + dz*dz)

        total_leg = upper_leg + lower_leg
        if dist >= total_leg:
            # Leg fully extended
            t = upper_leg / total_leg
            knee = (hip_pos[0] + dx * t,
                    hip_pos[1] + dy * t,
                    hip_pos[2] + dz * t)
            ankle = peg
        elif dist < 0.01:
            knee = (hip_pos[0] + sign * upper_leg * 0.5,
                    hip_pos[1], hip_pos[2] - upper_leg * 0.866)
            ankle = peg
        else:
            # Triangle IK — knee bends outward (laterally) and forward
            cos_a = (upper_leg*upper_leg + dist*dist - lower_leg*lower_leg) / (2.0*upper_leg*dist)
            cos_a = max(-1.0, min(1.0, cos_a))
            angle_a = math.acos(cos_a)

            ux, uy, uz = dx/dist, dy/dist, dz/dist
            # Knee bends outward (lateral) — perpendicular in X direction
            perp_x = sign * 1.0
            perp_y = 0.0
            perp_z = 0.0

            knee = (
                hip_pos[0] + ux * math.cos(angle_a) * upper_leg + perp_x * math.sin(angle_a) * upper_leg * 0.3,
                hip_pos[1] + uy * math.cos(angle_a) * upper_leg + perp_y * math.sin(angle_a) * upper_leg,
                hip_pos[2] + uz * math.cos(angle_a) * upper_leg + perp_z * math.sin(angle_a) * upper_leg,
            )
            ankle = peg

        legs[side] = {
            "hip": hip_pos,
            "knee": knee,
            "ankle": ankle,
        }

    return {
        "hip": hip,
        "shoulder_c": shoulder_c,
        "head_pt": head_pt,
        "eye_pt": eye_pt,
        "arms": arms,
        "legs": legs,
        "torso_len": torso_len,
        "neck_len": neck_len,
    }


# ── Build ────────────────────────────────────────────────────────────────────

def build(coll, prefix):
    """Create all objects for one rider (empties + meshes + constraints)."""
    # Central joints
    for suffix in ("Hip", "ShoulderC", "HeadPt", "EyePt"):
        meshutil.add_empty(coll, n(prefix, suffix), display="SPHERE", size=0.03)

    # Head + eye spheres
    meshutil.add_mesh_obj(coll, n(prefix, "Head"),
                          meshutil.make_sphere(n(prefix, "Head"), radius=_HEAD_R))
    meshutil.add_mesh_obj(coll, n(prefix, "Eye"),
                          meshutil.make_sphere(n(prefix, "Eye"), radius=0.025))

    # Arm joints: L/R × Shoulder, Elbow, Wrist
    for side in ("L", "R"):
        for suffix in ("Shoulder", "Elbow", "Wrist"):
            meshutil.add_empty(coll, n(prefix, "%s_%s" % (side, suffix)),
                               display="SPHERE", size=0.02)

    # Leg joints: L/R × Hip, Knee, Ankle
    for side in ("L", "R"):
        for suffix in ("Hip", "Knee", "Ankle"):
            meshutil.add_empty(coll, n(prefix, "%s_%s" % (side, suffix)),
                               display="SPHERE", size=0.02)

    # Limb cylinders with COPY_LOCATION + STRETCH_TO constraints
    _BASE_R = 0.020
    limb_defs = [
        # Central spine
        ("Limb_Torso",  "Hip",         "ShoulderC"),
        ("Limb_Neck",   "ShoulderC",   "HeadPt"),
    ]
    # Arms
    for side in ("L", "R"):
        limb_defs += [
            ("Limb_%s_UpperArm" % side, "%s_Shoulder" % side, "%s_Elbow" % side),
            ("Limb_%s_Forearm" % side,   "%s_Elbow" % side,    "%s_Wrist" % side),
        ]
    # Legs
    for side in ("L", "R"):
        limb_defs += [
            ("Limb_%s_Thigh" % side,  "%s_Hip" % side,  "%s_Knee" % side),
            ("Limb_%s_Shank" % side,  "%s_Knee" % side, "%s_Ankle" % side),
        ]

    for limb_s, prox_s, dist_s in limb_defs:
        nm   = n(prefix, limb_s)
        mesh = meshutil.make_cylinder(nm, radius=_BASE_R, length=1.0,
                                      axis="Y", centered=False, segs=10)
        limb = meshutil.add_mesh_obj(coll, nm, mesh)
        c_loc = limb.constraints.new("COPY_LOCATION")
        c_loc.target = meshutil.obj(coll, n(prefix, prox_s))
        c_str = limb.constraints.new("STRETCH_TO")
        c_str.target = meshutil.obj(coll, n(prefix, dist_s))
        c_str.rest_length = 1.0
        c_str.volume = "NO_VOLUME"


def build_all(coll, props):
    for prefix, *_ in rider_layout(props):
        build(coll, prefix)


# ── Position ─────────────────────────────────────────────────────────────────

def position(coll, prefix, seat_y, seat_x, props):
    """Reposition one rider from current properties."""
    chain = _compute_chain(seat_y, seat_x, props)

    # Central skeleton
    _set_loc(coll, prefix, "Hip",       chain["hip"])
    _set_loc(coll, prefix, "ShoulderC", chain["shoulder_c"])
    _set_loc(coll, prefix, "HeadPt",    chain["head_pt"])
    _set_loc(coll, prefix, "EyePt",     chain["eye_pt"])

    head_obj = meshutil.obj(coll, n(prefix, "Head"))
    if head_obj:
        head_obj.location = chain["head_pt"]

    eye_obj = meshutil.obj(coll, n(prefix, "Eye"))
    if eye_obj:
        eye_obj.location = chain["eye_pt"]

    # Arms
    for side in ("L", "R"):
        arm = chain["arms"][side]
        _set_loc(coll, prefix, "%s_Shoulder" % side, arm["shoulder"])
        _set_loc(coll, prefix, "%s_Elbow" % side,    arm["elbow"])
        _set_loc(coll, prefix, "%s_Wrist" % side,    arm["wrist"])

    # Legs
    for side in ("L", "R"):
        leg = chain["legs"][side]
        _set_loc(coll, prefix, "%s_Hip" % side,   leg["hip"])
        _set_loc(coll, prefix, "%s_Knee" % side,  leg["knee"])
        _set_loc(coll, prefix, "%s_Ankle" % side, leg["ankle"])

    # Limb thickness
    t = props.limb_thickness
    for suffix_list in (
        ["Limb_Torso", "Limb_Neck"],
        ["Limb_L_UpperArm", "Limb_L_Forearm", "Limb_R_UpperArm", "Limb_R_Forearm"],
        ["Limb_L_Thigh", "Limb_L_Shank", "Limb_R_Thigh", "Limb_R_Shank"],
    ):
        for s in suffix_list:
            limb = meshutil.obj(coll, n(prefix, s))
            if limb:
                limb.scale.x = t
                limb.scale.z = t


def position_all(coll, props):
    """Position every rider."""
    for prefix, seat_y, seat_x in rider_layout(props):
        position(coll, prefix, seat_y, seat_x, props)


def _set_loc(coll, prefix, suffix, xyz):
    e = meshutil.obj(coll, n(prefix, suffix))
    if e:
        e.location = xyz
