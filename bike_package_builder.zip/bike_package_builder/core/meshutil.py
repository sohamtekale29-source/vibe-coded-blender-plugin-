"""Context-independent mesh/object helpers and collection management.

Kept free of imports from builder/rider/chassis/tires/update so every module can
depend on it without circular imports.
"""
import math
import bpy
import bmesh

COLLECTION = "Bike Package"


def make_cylinder(name, radius, length, axis="Z", centered=True, segs=16):
    """A capped cylinder of the given radius/length along the chosen axis."""
    bm = bmesh.new()
    a0, a1 = (-length / 2.0, length / 2.0) if centered else (0.0, length)
    ring0, ring1 = [], []
    for i in range(segs):
        ang = 2.0 * math.pi * i / segs
        c, s = radius * math.cos(ang), radius * math.sin(ang)
        if axis == "Z":
            v0, v1 = (c, s, a0), (c, s, a1)
        elif axis == "Y":
            v0, v1 = (c, a0, s), (c, a1, s)
        else:  # 'X'
            v0, v1 = (a0, c, s), (a1, c, s)
        ring0.append(bm.verts.new(v0))
        ring1.append(bm.verts.new(v1))
    bm.verts.ensure_lookup_table()
    for i in range(segs):
        j = (i + 1) % segs
        bm.faces.new((ring0[i], ring0[j], ring1[j], ring1[i]))
    bm.faces.new(tuple(reversed(ring0)))
    bm.faces.new(tuple(ring1))
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    return me


def make_sphere(name, radius, subdivisions=2):
    bm = bmesh.new()
    bmesh.ops.create_icosphere(bm, subdivisions=subdivisions, radius=radius)
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    return me


def make_plane(name, half):
    bm = bmesh.new()
    verts = [bm.verts.new(v) for v in
             [(-half, -half, 0.0), (half, -half, 0.0), (half, half, 0.0), (-half, half, 0.0)]]
    bm.faces.new(verts)
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    return me


def add_mesh_obj(coll, name, mesh):
    obj = bpy.data.objects.new(name, mesh)
    coll.objects.link(obj)
    return obj


def add_empty(coll, name, display="SPHERE", size=0.04):
    obj = bpy.data.objects.new(name, None)
    obj.empty_display_type = display
    obj.empty_display_size = size
    coll.objects.link(obj)
    return obj


def get_collection():
    return bpy.data.collections.get(COLLECTION)


def obj(coll, name):
    """Look up a child object of the collection by name (or None)."""
    return coll.objects.get(name) if coll else None


def clear(context):
    """Remove the package collection and all of its objects/meshes."""
    coll = get_collection()
    if coll is None:
        return
    for o in list(coll.objects):
        mesh = o.data if isinstance(o.data, bpy.types.Mesh) else None
        bpy.data.objects.remove(o, do_unlink=True)
        if mesh is not None and mesh.users == 0:
            bpy.data.meshes.remove(mesh)
    for scene in bpy.data.scenes:
        if coll.name in scene.collection.children:
            scene.collection.children.unlink(coll)
    bpy.data.collections.remove(coll)
