"""Motorcycle tires — front and rear, always different sizes.

Unlike cars, motorcycles always have different front/rear tires (no "stagger" toggle).
Tires are unit cylinders scaled per update (no mesh regen on size change).
"""
import math
from . import meshutil

TIRE_FRONT = "BPB_Tire_Front"
TIRE_REAR  = "BPB_Tire_Rear"


def build(coll):
    for name in (TIRE_FRONT, TIRE_REAR):
        mesh = meshutil.make_cylinder(name, radius=1.0, length=1.0,
                                      axis="Z", centered=True, segs=24)
        meshutil.add_mesh_obj(coll, name, mesh)


def position(coll, props):
    from . import mm
    from . import tirecode

    # Parse tire codes
    front_parsed = tirecode.parse(props.front_tire_code)
    rear_parsed  = tirecode.parse(props.rear_tire_code)

    front_r = mm(front_parsed["diameter"]) * 0.5 if front_parsed else mm(300)
    front_w = mm(front_parsed["width"]) if front_parsed else mm(100)
    rear_r  = mm(rear_parsed["diameter"]) * 0.5 if rear_parsed else mm(300)
    rear_w  = mm(rear_parsed["width"]) if rear_parsed else mm(130)

    total_len = mm(props.overall_length)
    front_y = mm(props.front_overhang)
    rear_y  = total_len - mm(props.rear_overhang)

    # Front tire — centred on front axle, on ground
    ft = meshutil.obj(coll, TIRE_FRONT)
    if ft:
        ft.location       = (0.0, front_y, front_r)
        ft.scale          = (front_r, front_r, front_w)
        ft.rotation_euler = (0.0, math.radians(90.0), 0.0)

    # Rear tire — centred on rear axle, on ground
    rt = meshutil.obj(coll, TIRE_REAR)
    if rt:
        rt.location       = (0.0, rear_y, rear_r)
        rt.scale          = (rear_r, rear_r, rear_w)
        rt.rotation_euler = (0.0, math.radians(90.0), 0.0)
