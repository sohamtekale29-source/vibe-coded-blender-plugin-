"""Apply per-component materials and visual settings to BPB_ objects.

Called from update.refresh() on every prop change so colors stay live.
Works with use_nodes=False (Workbench / Material Preview friendly).
"""
import bpy
from .rider import rider_layout, n as rn
from .tires import TIRE_FRONT, TIRE_REAR
from .chassis import FORK_LINE


def _mat(name, rgba):
    """Get-or-create a named material and set its diffuse color."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def _assign(obj, mat):
    if obj is None or obj.data is None:
        return
    slots = getattr(obj.data, "materials", None)
    if slots is None:
        return
    if len(slots) == 0:
        slots.append(mat)
    else:
        slots[0] = mat


def apply_colors(coll, props):
    c_r = tuple(props.color_rider)
    c_t = tuple(props.color_tires)
    c_c = tuple(props.color_chassis)

    mat_r = _mat("BPB_Mat_Rider",   c_r)
    mat_t = _mat("BPB_Mat_Tires",   c_t)
    mat_c = _mat("BPB_Mat_Chassis", c_c)
    mat_eye = _mat("BPB_Mat_Eye",   (1.0, 0.95, 0.0, 1.0))

    # Tires
    _assign(coll.objects.get(TIRE_FRONT), mat_t)
    _assign(coll.objects.get(TIRE_REAR),  mat_t)

    # Fork line
    _assign(coll.objects.get(FORK_LINE), mat_c)

    # Per-rider manikin objects
    for prefix, *_ in rider_layout(props):
        # Central limbs
        for suffix in ("Limb_Torso", "Limb_Neck", "Head"):
            _assign(coll.objects.get(rn(prefix, suffix)), mat_r)
        _assign(coll.objects.get(rn(prefix, "Eye")), mat_eye)
        # Arms + legs
        for side in ("L", "R"):
            for part in ("Limb_%s_UpperArm", "Limb_%s_Forearm",
                         "Limb_%s_Thigh", "Limb_%s_Shank"):
                _assign(coll.objects.get(rn(prefix, part % side)), mat_r)
