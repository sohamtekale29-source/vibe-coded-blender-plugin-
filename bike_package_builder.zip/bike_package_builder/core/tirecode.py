"""Parse motorcycle tire-size notation, e.g. "120/70ZR17" or "80/100-17" -> dims.

Motorcycle tires embed speed ratings (Z, W, H, V) between aspect and R/-.
Overall diameter = rim diameter + 2 x sidewall height
sidewall height  = section width x (aspect ratio / 100)
"""
import re

# Matches: 120/70ZR17, 80/100-17, 110/70R17, 90/90-12, 180/55ZR17
_PATTERN = re.compile(
    r"(\d{2,3})\s*/\s*(\d{2,3})\s*(?:[A-Z]*R|[-])\s*(\d{1,2})",
    re.IGNORECASE
)


def parse(code):
    """Return {"width", "aspect", "rim_in", "diameter"} (mm) or None if unparsable."""
    if not code:
        return None
    m = _PATTERN.search(code)
    if not m:
        return None
    width = float(m.group(1))
    aspect = float(m.group(2))
    rim_in = float(m.group(3))
    diameter = rim_in * 25.4 + 2.0 * (width * aspect / 100.0)
    return {"width": width, "aspect": aspect, "rim_in": rim_in, "diameter": diameter}
