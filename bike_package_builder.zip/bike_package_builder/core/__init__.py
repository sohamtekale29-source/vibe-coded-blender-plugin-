"""Core package: data loaders shared by builder / rider / chassis / tires / update."""
import os
import json

# Add-on root (parent of this 'core' folder)
_ADDON_DIR = os.path.dirname(os.path.dirname(__file__))
_DATA_DIR = os.path.join(_ADDON_DIR, "data")

# Unit helper: properties are stored in millimetres; 1 Blender unit = 1 metre.
MM = 0.001


def mm(value):
    """Convert a millimetre value to Blender metres."""
    return value * MM


def _load(filename):
    with open(os.path.join(_DATA_DIR, filename), "r", encoding="utf-8") as fh:
        return json.load(fh)


def rider_data():
    """Return dict keyed by percentile string ('5','50','95')."""
    return _load("rider_manikin.json")["percentiles"]


def bike_presets():
    """Return dict keyed by preset name ('Commuter', 'Sport / Naked', ...)."""
    return _load("bike_presets.json")["presets"]


def tire_catalog():
    """Return dict keyed by catalog entry label ('Commuter', 'Sport Radial', ...)."""
    return _load("tire_catalog.json")["catalog"]


def posture_modes():
    """Return dict keyed by posture mode name ('Upright', 'Crouch', ...)."""
    return _load("posture_modes.json")["modes"]
