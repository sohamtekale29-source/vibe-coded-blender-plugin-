"""Motorcycle chassis skeleton — wireframe silhouette, axles, steering head,
handlebar empties, footpeg empties, and seat marker.

Bike runs along the Y axis (green line). Front wheel contact at Y = front_overhang.
Rear wheel contact at Y = overall_length - rear_overhang.
"""
import math
import bpy
import bmesh
from . import meshutil

SILHOUETTE = "BPB_Silhouette"
AXLE_FRONT = "BPB_Axle_Front"
AXLE_REAR  = "BPB_Axle_Rear"
STEER_HEAD = "BPB_Steering_Head"
SEAT_PT    = "BPB_Seat_Point"
HB_LEFT    = "BPB_Handlebar_L"
HB_RIGHT   = "BPB_Handlebar_R"
FP_LEFT    = "BPB_Footpeg_L"
FP_RIGHT   = "BPB_Footpeg_R"
FORK_LINE  = "BPB_Fork_Line"
GROUND     = "BPB_Ground"

_MAT_SKEL  = "BPB_Mat_Skeleton"


def _wire_mat():
    mat = bpy.data.materials.get(_MAT_SKEL)
    if mat is None:
        mat = bpy.data.materials.new(_MAT_SKEL)
    mat.use_nodes = False
    mat.diffuse_color = (0.7, 0.85, 1.0, 1.0)
    return mat


def build(coll):
    """Create all chassis objects."""
    # Axle empties
    meshutil.add_empty(coll, AXLE_FRONT, display="PLAIN_AXES", size=0.12)
    meshutil.add_empty(coll, AXLE_REAR,  display="PLAIN_AXES", size=0.12)

    # Steering head
    meshutil.add_empty(coll, STEER_HEAD, display="SINGLE_ARROW", size=0.15)

    # Seat point
    meshutil.add_empty(coll, SEAT_PT, display="SPHERE", size=0.04)

    # Handlebar grips
    meshutil.add_empty(coll, HB_LEFT,  display="SPHERE", size=0.025)
    meshutil.add_empty(coll, HB_RIGHT, display="SPHERE", size=0.025)

    # Footpegs
    meshutil.add_empty(coll, FP_LEFT,  display="SPHERE", size=0.025)
    meshutil.add_empty(coll, FP_RIGHT, display="SPHERE", size=0.025)

    # Side-view silhouette (wireframe box — simplified bike envelope)
    bm = bmesh.new()
    # Unit box centered at origin — will be scaled/positioned per update
    corners = [(-1, -1, -1), (1, -1, -1), (1,  1, -1), (-1,  1, -1),
               (-1, -1,  1), (1, -1,  1), (1,  1,  1), (-1,  1,  1)]
    vs = [bm.verts.new(c) for c in corners]
    for a, b in [(0,1),(1,2),(2,3),(3,0),
                 (4,5),(5,6),(6,7),(7,4),
                 (0,4),(1,5),(2,6),(3,7)]:
        bm.edges.new((vs[a], vs[b]))
    me = bpy.data.meshes.new(SILHOUETTE)
    bm.to_mesh(me)
    bm.free()
    obj = meshutil.add_mesh_obj(coll, SILHOUETTE, me)
    obj.display_type = 'WIRE'
    obj.color = (0.7, 0.85, 1.0, 1.0)
    me.materials.append(_wire_mat())

    # Fork line (steering axis visualization)
    bm2 = bmesh.new()
    v0 = bm2.verts.new((0.0, 0.0, 0.0))
    v1 = bm2.verts.new((0.0, 0.0, 1.0))
    bm2.edges.new((v0, v1))
    me2 = bpy.data.meshes.new(FORK_LINE)
    bm2.to_mesh(me2)
    bm2.free()
    fork = meshutil.add_mesh_obj(coll, FORK_LINE, me2)
    fork.display_type = 'WIRE'
    fork.color = (1.0, 0.6, 0.1, 1.0)

    # Ground reference plane
    ground_me = meshutil.make_plane(GROUND, 1.5)
    ground = meshutil.add_mesh_obj(coll, GROUND, ground_me)
    ground.display_type = 'WIRE'
    ground.color = (0.3, 0.3, 0.3, 1.0)
    return obj


def position(coll, props):
    """Reposition all chassis objects from current properties."""
    from . import mm

    total_len = mm(props.overall_length)
    half_w    = mm(props.overall_width) * 0.5
    half_h    = mm(props.overall_height) * 0.5
    gc        = mm(props.ground_clearance)

    front_y = mm(props.front_overhang)
    rear_y  = total_len - mm(props.rear_overhang)

    seat_z  = mm(props.seat_height)
    seat_y  = mm(props.seat_fore_aft)

    hb_z    = mm(props.handlebar_height)
    hb_half = mm(props.handlebar_width) * 0.5

    fp_z    = mm(props.footpeg_height)
    fp_y    = front_y + mm(props.footpeg_fore_aft)
    fp_half = mm(150)  # ~150mm lateral offset

    # Front tire radius for axle height
    front_parsed = None
    rear_parsed = None
    try:
        from . import tirecode
        front_parsed = tirecode.parse(props.front_tire_code)
        rear_parsed = tirecode.parse(props.rear_tire_code)
    except Exception:
        pass

    front_r = mm(front_parsed["diameter"]) * 0.5 if front_parsed else mm(300)
    rear_r  = mm(rear_parsed["diameter"]) * 0.5 if rear_parsed else mm(300)

    # Axles
    front = meshutil.obj(coll, AXLE_FRONT)
    rear  = meshutil.obj(coll, AXLE_REAR)
    if front:
        front.location = (0.0, front_y, front_r)
    if rear:
        rear.location = (0.0, rear_y, rear_r)

    # Steering head — positioned above front axle at rake angle
    rake_rad = math.radians(props.rake_angle)
    steer = meshutil.obj(coll, STEER_HEAD)
    if steer:
        steer_z = front_r + mm(400)  # Approximate steering head height
        steer.location = (0.0, front_y, steer_z)
        steer.rotation_euler = (rake_rad, 0.0, 0.0)

    # Seat point
    sp = meshutil.obj(coll, SEAT_PT)
    if sp:
        sp.location = (0.0, seat_y, seat_z)

    # Handlebar grips
    hb_l = meshutil.obj(coll, HB_LEFT)
    hb_r = meshutil.obj(coll, HB_RIGHT)
    if hb_l:
        hb_l.location = (+hb_half, front_y, hb_z)
    if hb_r:
        hb_r.location = (-hb_half, front_y, hb_z)

    # Footpegs
    fp_l = meshutil.obj(coll, FP_LEFT)
    fp_r = meshutil.obj(coll, FP_RIGHT)
    if fp_l:
        fp_l.location = (+fp_half, fp_y, fp_z)
    if fp_r:
        fp_r.location = (-fp_half, fp_y, fp_z)

    # Silhouette box
    sil = meshutil.obj(coll, SILHOUETTE)
    if sil:
        sil.location      = (0.0, total_len * 0.5, gc + half_h)
        sil.scale         = (half_w, total_len * 0.5, half_h)
        sil.hide_viewport = not props.show_silhouette
        sil.hide_render   = not props.show_silhouette

    # Fork line — from steering head down to front axle along rake
    fork = meshutil.obj(coll, FORK_LINE)
    if fork:
        fork_len = (steer_z - front_r) if steer else mm(400)
        fork.location = (0.0, front_y, front_r)
        fork.scale    = (1.0, 1.0, max(0.01, fork_len))
        fork.rotation_euler = (rake_rad - math.pi, 0.0, 0.0)

    # Ground plane
    gnd = meshutil.obj(coll, GROUND)
    if gnd:
        gnd.location = (0.0, total_len * 0.5, 0.0)
